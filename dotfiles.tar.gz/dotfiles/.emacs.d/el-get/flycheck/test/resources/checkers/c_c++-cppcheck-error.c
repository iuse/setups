int derefNull(void)
{
    int* nil = NULL;
    return *nil;
}
