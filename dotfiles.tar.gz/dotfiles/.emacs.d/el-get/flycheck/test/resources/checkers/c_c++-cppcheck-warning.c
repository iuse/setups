bool f(bool x, int y) {
    return x == y;
}
