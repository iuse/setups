// A simple import error in Go

package testpackage

func Foo() {
	fmt.Println("foo")
}
