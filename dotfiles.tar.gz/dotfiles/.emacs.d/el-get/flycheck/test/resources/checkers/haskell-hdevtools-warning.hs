module Foo where

foo = 10 :: Integer
