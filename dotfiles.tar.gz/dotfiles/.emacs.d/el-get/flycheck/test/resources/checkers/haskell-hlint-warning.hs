main :: IO ()
main = (putStrLn "Foobar")
