/** Use eval to trigger a warning */

eval("alert();");
