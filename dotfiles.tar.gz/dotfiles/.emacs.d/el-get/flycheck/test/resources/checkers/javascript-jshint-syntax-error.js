/** A missing semicolon */

var foo = "Hello world);
