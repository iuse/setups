/** An unused variable */


(function() {
    var foo = ["Hello world"];
}());
