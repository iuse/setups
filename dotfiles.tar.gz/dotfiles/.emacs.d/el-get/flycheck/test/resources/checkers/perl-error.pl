# An unused variable

use warnings;
$x = 10;
