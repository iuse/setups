# A syntax error

use strict
use warnings;
$x = 10;
