# Test a very long line

our_chicken_stable = []

eggs = [chicken.make_egg() for chicken in our_chicken_stable]
