# Add superfluous spaces around an operator
#
# Checkers: Flake8


def foo(spam = 'eggs'):
    pass
