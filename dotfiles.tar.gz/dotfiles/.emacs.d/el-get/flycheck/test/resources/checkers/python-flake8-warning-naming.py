# Using non PEP8 compliant name
#
# Checkers: Flake8 with pep8-naming plug-in


class myclass(object):
    def MyFunction():
        X = 12
        return X
