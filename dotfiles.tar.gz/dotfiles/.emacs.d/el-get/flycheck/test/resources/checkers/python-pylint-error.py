# Importing an unknown module

import spam

spam.with_eggs()
