# A straight syntax error

foo = import bar
