Hello, there:

.. warning::

   Foo
   ===

.. note::

   Bar
   ===
