# Triggers some warnings in RuboCop

arr = [:one, :twoTho, :top_gun]
puts "test"
