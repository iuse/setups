# generates warning 'possibly useless use of == in void context'

test == 20
