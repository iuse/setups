// Scala syntax error

object {
  println("hello, world")
}
