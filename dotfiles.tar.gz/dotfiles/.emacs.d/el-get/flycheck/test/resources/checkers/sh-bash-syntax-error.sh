# A syntax error caused by a Bash-only redirection

cat <(echo blah)
