# A syntax error resulting from a missing semicolon

if true then
    echo "Hello World"
fi
