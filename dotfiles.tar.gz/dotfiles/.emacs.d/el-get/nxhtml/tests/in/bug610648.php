Here is some text.

<?php echo 'And this is a PHP chunk.'?>
