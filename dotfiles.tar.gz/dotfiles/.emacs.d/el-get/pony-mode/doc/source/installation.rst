.. _installation:

Installation
------------

1. clone this repo somewhere $ git clone https://github.com/davidmiller/pony-mode
2. Byte-compile the file::

    M-x byte-compile-file
3. Add the path to your load-path::

    (add-to-list 'load-path "path/to/pony-mode")
4. Add to your .emacs::

    (require 'pony-mode)
5. Enjoy
